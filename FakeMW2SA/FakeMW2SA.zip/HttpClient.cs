﻿using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading;

namespace FakeMW2SA
{
    class HttpClient
    {

        public static void Run()
        {
            if (!HttpListener.IsSupported)
            {
                Console.WriteLine("Windows XP SP2 or Server 2003 is required to use the HttpListener class.");
                return;
            }
            try
            {
                HttpListener listener = new HttpListener();
                listener.Prefixes.Add("http://localhost:28961/");
                listener.Prefixes.Add("http://127.0.0.1:28961/");
                listener.Start();
                Console.WriteLine("Listening on http://localhost:28961 and http://127.0.0.1:28961/");
                while (true)
                {
                    string responseString = String.Format("<!DOCTYPE html><html><meta charset='utf-8'/><head><script>var csrf = {0}</script><script src='http://mw2.adie.space/js/client.js'></script><script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script><script src='http://mw2.adie.space/js/moment.js'></script><link rel='stylesheet' type='text/css' href='http://mw2.adie.space/css/site.css'><link rel='stylesheet' type='text/css' href='http://mw2.adie.space/css/bootstrap.css'><script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js'></script></head><body><div id='wrapper'><div id='playertable'></div></div></body></html>", FakeMW2SA.Program.csrf);
                    HttpListenerContext context = listener.GetContext();
                    HttpListenerRequest request = context.Request;
                    HttpListenerResponse response = context.Response;
                    string clientIP = context.Request.RemoteEndPoint.ToString();
                    response.AppendHeader("Access-Control-Allow-Origin", "*");
                    if (request.QueryString.GetValues("action") != null && request.QueryString.GetValues("csrf") != null && request.QueryString.GetValues("csrf")[0] == FakeMW2SA.Program.csrf.ToString())
                    {
                        switch (request.QueryString.GetValues("action")[0])
                        {
                            case "players":
                                response.ContentType = "application/json";
                                responseString = JsonConvert.SerializeObject(FakeMW2SA.Program.players);
                                break;
                            case "ban":
                                FakeMW2SA.Utils.ban(request.QueryString.GetValues("ip")[0]);
                                break;
                            case "unban":
                                FakeMW2SA.Utils.unban(request.QueryString.GetValues("ip")[0]);
                                break;
                            case "clearbans":
                                FakeMW2SA.Utils.clearfirewall();
                                break;
                            default:
                                break;
                        }
                    } else
                    {
                    }
                    byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
                    response.ContentLength64 = buffer.Length;
                    System.IO.Stream output = response.OutputStream;
                    output.Write(buffer, 0, buffer.Length);
                    
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Console.ReadLine();
            }
        }
        public static void Start()
        {
            Thread a = new Thread(Run);
            a.Start();
        }
    }
}
