﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using MaxMind.GeoIP2;
using Newtonsoft.Json.Linq;

namespace FakeMW2SA
{
    public class PlayerModel
    {
        public PlayerModel(string i, string s, bool m)
        {
                SteamId = s;
                memberjoin = m;
                Ip = i;
                TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
                int secondsSinceEpoch = (int)t.TotalSeconds;
                lastseen = FakeMW2SA.Utils.GetEpochSeconds();
         }
        public string SteamId { get; set; }
        public string lobby { get; set; }
        public string Ip { get; set; }
        public int VACtime { get; set; } 
        public string VAC { get; set; }
        public string Name { get; set; }
        public string OriginalName { get; set; }
        public string Mw2Hours { get; set; }
        public string CSGOhours { get; set; }
        public string CSsourcehours { get; set; }
        public string CShours { get; set; }
        public int Privacy { get; set; }
        public string Location { get; set; }
        public string Banned { get; set; } 
        public int lastseen { get; set; }
        public int ID { get; set; }
        public string CountryCode { get; set; } 
        public string Level { get; set; }
        public string Presteige { get; set; }
        public int unknown1 { get; set; }
        public int unknown2 { get; set; }
        public int missing { get; set; }
        public int deaths { get; set; }
        public int score { get; set; }
        public int partyID { get; set; }
        public bool host { get; set; }
        public bool memberjoin { get; set; }
    }
}
