﻿using MaxMind.GeoIP2;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FakeMW2SA
{
    class Utils
    {
        public static void runCommand(string command)
        {
            Process cmd = new Process();
            cmd.StartInfo.FileName = "cmd.exe";
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.Start();

            cmd.StandardInput.Flush();
            cmd.StandardInput.WriteLine(command);
            cmd.StandardInput.Flush();
            cmd.StandardInput.Close();
            cmd.WaitForExit();
        }
        public static void firewall(string ip)
        {
            runCommand("route add " + ip + " mask 255.255.255.255 12.34.56.78 IF 1 ");
        }
        public static void clearfirewall()
        {
            foreach (PlayerModel each in FakeMW2SA.Program.players)
            {
                each.Banned = "False";
            }
            runCommand("route delete * 12.34.56.78");
        }
        public static void unban(string ip)
        {
            runCommand("route delete " + ip + " 12.34.56.78");
        }
        public static void ban(string ip)
        {
            FakeMW2SA.Program.players.Find(x => x.Ip == ip).Banned = "True";
            Console.WriteLine("route add " + ip + " 12.34.56.78");
            runCommand("route add " + ip + " 12.34.56.78 IF 1");
        }
        public static int GetEpochSeconds()
        {
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            return (int)t.TotalSeconds;
        }
        public static string ReverseBytes(string val)
        {
            var Result = "";
            for (int i = val.Count(); i > 0; i = i - 2)
            {
                Result = Result + val.Substring(i - 2, 2);
            }
            return Result;
        }
        //This is for UTF-8 compatibility
        public static string ConvertHex(String hexString)
        {
            try
            {
                string ascii = string.Empty;

                for (int i = 0; i < hexString.Length; i += 2)
                {
                    String hs = string.Empty;

                    hs = hexString.Substring(i, 2);
                    uint decval = System.Convert.ToUInt32(hs, 16);
                    char character = System.Convert.ToChar(decval);
                    ascii += character;

                }

                return ascii;
            }
            catch (Exception ex)
            {
                Console.WriteLine(hexString);
                Console.WriteLine(ex.Message);
            }

            return string.Empty;
        }
        public static byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length / 2;
            byte[] bytes = new byte[NumberChars];
            using (var sr = new StringReader(hex))
            {
                for (int i = 0; i < NumberChars; i++)
                    bytes[i] =
                      Convert.ToByte(new string(new char[2] { (char)sr.Read(), (char)sr.Read() }), 16);
            }
            return bytes;
        }
        public static void sethost(string SourceIP)
        {
            foreach (PlayerModel each in FakeMW2SA.Program.players)
            {
                each.host = false;
            }
            if ((FakeMW2SA.Program.players.Find(x => x.Ip == SourceIP && x.memberjoin == false) != null))
            {
                (FakeMW2SA.Program.players.Find(x => x.Ip == SourceIP)).host = true;
            }
            else if ((FakeMW2SA.Program.players.Find(x => x.Ip == FakeMW2SA.Program.myexternalip) != null))
            {
                (FakeMW2SA.Program.players.Find(x => x.Ip == FakeMW2SA.Program.myexternalip)).host = true;
            }
        }
        public static int findPartyID()
        {

            for (int i = 1; i <= 1000; i++)
            {
                if ((FakeMW2SA.Program.players.Find(x => x.partyID == i)) == null)
                {
                    return i;
                }
            }
            return 999;
        }
        public static void callapis()
        {
            string SteamIDs = "";
            List<PlayerModel> playerstolookup = new List<PlayerModel>();
            foreach (PlayerModel each in FakeMW2SA.Program.players)
            {
                if (each.OriginalName == null){ playerstolookup.Add(each); }
            }
            foreach (FakeMW2SA.PlayerModel each in playerstolookup) { SteamIDs = SteamIDs + each.SteamId + ","; }
            if (playerstolookup.Count > 0)
            {
                try
                {
                    using (WebClient wc = new WebClient())
                    {
                        wc.Encoding = System.Text.Encoding.UTF8;
                        FakeMW2SA.Program.WriteOnBottomLine("apicalls");
                        string url = "https://mw2.adie.space/players.php?steamids=" + SteamIDs;
                        var json = wc.DownloadString(url);
                        var apidata = JObject.Parse(json);
                        foreach (JToken each in apidata["response"]["players"])
                        {
                            var player = FakeMW2SA.Program.players.Find(x => x.SteamId == each["steamid"].ToString());
                            if (each["personaname"] != null) { player.OriginalName = each["personaname"].ToString(); }
                            if (each["lobbysteamid"] != null) { player.lobby = each["lobbysteamid"].ToString(); }
                            if (each["communityvisibilitystate"] != null) { player.Privacy = Convert.ToInt32(each["communityvisibilitystate"]); }
                        }
                    }
                    using (WebClient wc = new WebClient())
                    {
                        wc.Encoding = System.Text.Encoding.UTF8;

                        foreach (PlayerModel player in playerstolookup)
                        {
                            if (player.Privacy < 3)
                            {
                                player.Mw2Hours = "Private";
                                player.CSGOhours = "Private";
                                player.CShours = "Private";
                                player.CSsourcehours = "Private";
                            }
                            else
                            {
                                FakeMW2SA.Program.WriteOnBottomLine("apicalls");
                                string url = "http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key=8AD0DEE15680A032B366F0BD38DF70ED&steamid=" + player.SteamId;
                                var json = wc.DownloadString(url);
                                var apidata = JObject.Parse(json);
                                if (apidata["response"]["games"] != null)
                                {
                                    foreach (JObject each in apidata["response"]["games"])
                                    {
                                        if (each["appid"].ToString() == "10190")
                                        {
                                            string Hours = each["playtime_forever"].ToString();
                                            Hours = (Int32.Parse(Hours) / 60).ToString();
                                            player.Mw2Hours = Hours;

                                        }
                                        else if (each["appid"].ToString() == "730")
                                        {
                                            string Hours = each["playtime_forever"].ToString();
                                            Hours = (Int32.Parse(Hours) / 60).ToString();
                                            player.CSGOhours = Hours;
                                        }
                                        else if (each["appid"].ToString() == "240")
                                        {
                                            string Hours = each["playtime_forever"].ToString();
                                            Hours = (Int32.Parse(Hours) / 60).ToString();
                                            player.CSsourcehours = Hours;
                                        }
                                        else if (each["appid"].ToString() == "10")
                                        {
                                            string Hours = each["playtime_forever"].ToString();
                                            Hours = (Int32.Parse(Hours) / 60).ToString();
                                            player.CShours = Hours;
                                        }
                                    }
                                }
                            }
                        }

                    }
                    using (WebClient wc = new WebClient())
                    {
                        wc.Encoding = System.Text.Encoding.UTF8;
                        FakeMW2SA.Program.WriteOnBottomLine("apicalls");
                        string url = "https://mw2.adie.space/bans.php?steamids=" + SteamIDs;
                        var json = wc.DownloadString(url);
                        var apidata = JObject.Parse(json);
                        foreach (JObject each in apidata["players"])
                        {
                            var player = FakeMW2SA.Program.players.Find(x => x.SteamId == each["SteamId"].ToString());
                            if (each["VACBanned"].ToString() == "False")
                            {
                                player.VAC = "False";
                            }
                            else
                            {
                                player.VACtime = FakeMW2SA.Utils.GetEpochSeconds() - (each["DaysSinceLastBan"].ToObject<int>() * 86400);
                                player.VAC = each["NumberOfVACBans"].ToObject<string>();
                            }
                        }
                    }
                    if (FakeMW2SA.Program.geoip)
                    {
                        try
                        {
                            using (var reader = new DatabaseReader(@"./GeoLite2-City.mmdb"))
                            {
                                foreach (PlayerModel player in playerstolookup)
                                {
                                    var city = reader.City(player.Ip);
                                    player.Location = (city.Country.Name);
                                    if (city.MostSpecificSubdivision.Name != null)
                                    {
                                        player.Location += ", " + city.MostSpecificSubdivision.Name;
                                        if (city.City.Name != null)
                                        {
                                            player.Location += ", " + city.City.Name;
                                        }
                                    }
                                    player.CountryCode = city.Country.IsoCode;
                                }
                            }
                        }
                        catch
                        {

                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }


        }

        public static void getsteamID()
        {
            if (File.Exists("C:\\Program Files (x86)\\Steam\\config\\loginusers.vdf"))
            {
                
            }
            else if (File.Exists(Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\WOW6432Node\\Valve\\Steam\\", "InstallPath", "null").ToString() + "\\config\\loginusers.vdf"))
            {
                Console.WriteLine("Geolocation file not found. Disabling player location services.");
            }
        }
    }

}
